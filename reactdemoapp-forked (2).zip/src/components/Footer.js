export default function Footer() {
  return (
    <div className="footer">
      <h5>Sky Betting and Gaming</h5>
    </div>
  );
}
